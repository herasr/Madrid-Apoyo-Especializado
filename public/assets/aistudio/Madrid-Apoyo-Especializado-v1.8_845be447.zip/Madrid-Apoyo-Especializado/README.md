# Madrid Apoyo Especializado v1.8 (DATAMAD 2026)

Buscador independiente de recursos sociales y sanitarios autorizados en la Comunidad de Madrid, basado en registros públicos oficiales.

## 🚀 Requisitos e Instalación

### Requisitos previos
- Node.js >= 18.0.0
- npm >= 9.0.0

### Pasos de instalación

```bash
# 1. Clonar el repositorio
git clone https://github.com/herasr/Madrid-Apoyo-Especializado.git
cd Madrid-Apoyo-Especializado

# 2. Instalar dependencias limpiamente
npm install

# 3. Descargar y procesar el registro oficial (genera public/data/registry/)
npm run ingest
#    o, con un CSV descargado a mano desde el portal:
npm run ingest -- --file atencion_social_registro_centros.csv

# 4. Iniciar el servidor de desarrollo
npm run dev
```

El servidor estará disponible en `http://localhost:3000`.

## 🗂️ Datos

| Conjunto | Editor | Licencia | Uso |
|---|---|---|---|
| [Registro de centros de atención social](https://datos.comunidad.madrid/catalogo/dataset/atencion_social_registro_centros) | Comunidad de Madrid | CC BY 4.0 | Fuente única del buscador |

`npm run ingest` (y la Action semanal `weekly-ingest.yml`) hace lo siguiente:

1. Localiza el CSV vigente mediante la API CKAN del portal (con la URL directa como alternativa).
2. Valida que es un CSV real (tamaño, que no sea HTML, columnas reconocibles, mínimo de registros). **Si algo falla, termina con error y no modifica ningún dato.**
3. Normaliza cada fila (codificación, separador, coordenadas UTM → WGS84) y descarta bajas y duplicados.
4. Clasifica cada centro contra la taxonomía **solo con términos que aparecen literalmente** en el registro.
5. Escribe `records.json`, `meta.json` (recuentos reales, mapa de columnas, SHA-256), `diff.json` (altas, bajas y cambios frente a la ingesta anterior) e `ingestion-log.json`.

Lo que el registro **no** publica (plazas libres, vía de acceso, edades en muchos casos) se muestra como «no consta / debe confirmarse», nunca se rellena.

Las 13 fichas de `src/data/specializedCentresData.ts` son **fixtures de demostración** escritas a mano para probar el motor; no se muestran en el buscador.

## 📦 Comandos Disponibles

- `npm run dev`: Inicia el servidor de desarrollo en la puerta 3000.
- `npm run build`: Compila la aplicación web optimizada para producción (`dist/`).
- `npm run lint`: Realiza la comprobación de tipos de TypeScript (`tsc --noEmit`).
- `npm run preview`: Sirve la build local para previsualización.
- `npm run ingest`: Descarga y procesa el registro oficial.
- `npm test`: Tests del motor y de la ingesta.

## 📋 Arquitectura y Principios de Diseño

1. **Procedencia registral**: todos los centros del buscador proceden del Registro de centros de atención social de la Comunidad de Madrid; cada ficha enlaza al conjunto de datos, la huella SHA-256 y la fila de origen.
2. **Modelo de Evidencia (A1, A2, B1, B2, C)**: Ordenación lexicográfica estricta donde la evidencia de especialización prevalece sobre la distancia.
3. **Privacidad Efímera (RGPD)**: No se almacenan términos de salud ni coordenadas GPS en servidores externos; la geolocalización es efímera en el navegador.
4. **Reproducibilidad Completa**: Todas las dimensiones de búsqueda se codifican en la URL de forma limpia para permitir su compartición.

## 📄 Licencia

Licencia Apache 2.0. Código abierto y transparente.
