/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Clasificación de registros oficiales contra la taxonomía ciudadana y
 * conversión al modelo `SpecializedCentre` que usa el motor de búsqueda.
 *
 * Regla de oro: solo se afirma lo que el texto del registro dice
 * literalmente. Todo lo demás queda como «no consta» / «debe confirmarse».
 */

import { RegistryRecord, REGISTRY_DATASET } from './schema';
import { CORE_PROFILES, EXPERIMENTAL_PROFILES, PENDING_PROFILES } from '../specializedTaxonomy';
import type { LifeStage, ProfileId, SpecializedCentre, SupportTypeId } from '../../types/specialized';

export function norm(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** Coincidencia de término completo. Las siglas cortas exigen mayúsculas en el texto original. */
export function containsTerm(originalText: string, term: string): boolean {
  const isAcronym = term.length <= 4 && term === term.toUpperCase();
  if (isAcronym) {
    return new RegExp(`(^|[^A-Za-zÁÉÍÓÚÑÜáéíóúñü])${escapeRegExp(term)}([^A-Za-zÁÉÍÓÚÑÜáéíóúñü]|$)`).test(originalText);
  }
  return new RegExp(`(^|[^a-z0-9])${escapeRegExp(norm(term))}([^a-z0-9]|$)`).test(norm(originalText));
}

const ALL_PROFILES = { ...CORE_PROFILES, ...EXPERIMENTAL_PROFILES, ...PENDING_PROFILES } as Record<string, { explicit_terms: string[]; synonyms: string[] }>;

/** Perfiles cuyo término explícito (o sinónimo) aparece literalmente en el registro. */
export function detectProfiles(text: string): { profile: ProfileId; term: string }[] {
  const hits: { profile: ProfileId; term: string }[] = [];
  for (const [id, def] of Object.entries(ALL_PROFILES)) {
    const term = [...def.explicit_terms, ...def.synonyms].find(t => containsTerm(text, t));
    if (term) hits.push({ profile: id, term });
  }
  return hits;
}

const SUPPORT_RULES: { support: SupportTypeId; terms: string[] }[] = [
  { support: 'day_care', terms: ['centro de dia', 'estancias diurnas', 'atencion diurna'] },
  { support: 'residential_care', terms: ['residencia', 'residencial', 'vivienda tutelada', 'piso tutelado', 'pisos tutelados', 'hogar'] },
  { support: 'employment_support', terms: ['centro ocupacional', 'centro especial de empleo', 'insercion laboral', 'empleo con apoyo'] },
  { support: 'rehabilitation', terms: ['rehabilitacion'] },
  { support: 'psychological_support', terms: ['rehabilitacion psicosocial', 'apoyo psicologico', 'atencion psicosocial'] },
  { support: 'speech_therapy', terms: ['logopedia'] },
  { support: 'occupational_therapy', terms: ['terapia ocupacional'] }
];

export function detectSupports(text: string): { support: SupportTypeId; term: string }[] {
  const out: { support: SupportTypeId; term: string }[] = [];
  for (const rule of SUPPORT_RULES) {
    const term = rule.terms.find(t => containsTerm(text, t));
    if (term) out.push({ support: rule.support, term });
  }
  return out;
}

const LIFE_STAGE_RULES: { stage: LifeStage; terms: string[] }[] = [
  { stage: 'early_childhood', terms: ['atencion temprana', 'primera infancia', '0 a 6 anos', '0-6 anos'] },
  { stage: 'minor', terms: ['menores', 'infancia', 'infantil', 'ninos', 'ninas', 'adolescentes', 'juvenil'] },
  { stage: 'adult', terms: ['adultos', 'adultas', 'personas adultas'] },
  { stage: 'older_adult', terms: ['personas mayores', 'mayores', 'tercera edad'] }
];

export function detectLifeStages(text: string): LifeStage[] {
  return LIFE_STAGE_RULES.filter(r => r.terms.some(t => containsTerm(text, t))).map(r => r.stage);
}

export function classifyOwnership(ownership: string, entity: string): SpecializedCentre['public_private_status'] {
  const t = norm(`${ownership} ${entity}`);
  if (!t) return 'no_consta';
  if (/concert/.test(t)) return 'concertado';
  if (/(public|comunidad de madrid|ayuntamiento|municipal|agencia madrilena|consejeria|administracion)/.test(t)) return 'red_publica';
  if (/(privad|asociacion|fundacion|\bs\.?l\.?u?\b|\bs\.?a\.?\b|cooperativa|congregacion|\borden\b)/.test(t)) return 'privado_autorizado';
  return 'no_consta';
}

/** Regla de alcance: qué registros entran en el buscador especializado. */
export const SCOPE_TERMS = [
  'discapacidad', 'diversidad funcional', 'atencion temprana', 'dano cerebral', 'autismo',
  'paralisis cerebral', 'esclerosis', 'lesion medular', 'enfermedad mental', 'dependencia'
];

export function isInScope(text: string, profileHits: unknown[]): boolean {
  return profileHits.length > 0 || SCOPE_TERMS.some(t => containsTerm(text, t));
}

export function registryText(r: RegistryRecord): string {
  return [r.name, r.centre_type, r.sector, r.target_population, r.extra_text].filter(Boolean).join(' · ');
}

/** Convierte un registro oficial en el modelo del motor, sin inventar atributos. */
export function registryRecordToCentre(r: RegistryRecord, ingestion: { retrieved_at: string; snapshot_date: string; sha256: string }): SpecializedCentre {
  const text = registryText(r);
  const profiles = detectProfiles(text);
  const supports = detectSupports(text);
  const stages = detectLifeStages(text);
  const hasCoords = r.lat !== null && r.lon !== null;
  const sourceFragment = [r.centre_type, r.sector, r.target_population].filter(Boolean).join(' · ') || r.name;
  const reviewer = 'Ingesta automática (sin revisión humana)';

  const limitations: string[] = [
    'Datos procedentes del registro administrativo: no informan de plazas libres, listas de espera ni vía de acceso.'
  ];
  if (stages.length === 0) limitations.push('El registro no publica la franja de edad atendida: debe confirmarse con el centro.');
  if (!hasCoords) limitations.push('El registro no incluye coordenadas: el centro no aparece en el mapa ni en el cálculo de distancia.');
  if (!r.phone && !r.email) limitations.push('El registro no publica teléfono ni correo de contacto.');

  return {
    centre_id: r.record_id,
    provider_id: r.entity ? `ENT-${norm(r.entity).replace(/[^a-z0-9]+/g, '-').slice(0, 60)}` : `ENT-${r.record_id}`,
    provider_name: r.entity || 'Entidad titular no publicada',
    official_name: r.name,
    resource_domain: 'social',
    sector: r.sector,
    centre_type: r.centre_type,
    subtype: r.target_population,
    public_private_status: classifyOwnership(r.ownership, r.entity),
    management_type: r.ownership || 'No consta',
    address: r.address,
    postal_code: r.postal_code,
    municipality: r.municipality,
    district: r.district || undefined,
    coordinates: hasCoords ? [r.lat as number, r.lon as number] : null,
    has_valid_coordinates: hasCoords,
    phone: r.phone,
    email: r.email,
    website: r.website,
    explicit_specialisations: profiles.map(p => p.profile),
    related_services: supports.map(s => s.term),
    supports: supports.map(s => s.support),
    services_offered: [],
    allowed_life_stages: stages.length > 0 ? stages : ['early_childhood', 'minor', 'adult', 'older_adult'],
    life_stages_source: stages.length > 0 ? 'registry_text' : 'not_published',
    data_origin: 'official_registry',
    access_route: {
      access_type: 'unknown',
      competent_body: 'No publicado en el registro',
      official_description: 'El registro de centros no indica la vía de acceso.',
      source_url: REGISTRY_DATASET.catalog_url,
      checked_at: ingestion.snapshot_date,
      next_step_action: 'Contacte con el centro o con sus servicios sociales municipales para conocer la vía de acceso.',
      availability_known: false,
      waiting_list_known: false
    },
    availability: {
      status: 'not_published',
      authorised_places: r.places,
      vacancies_known: false,
      source_url: REGISTRY_DATASET.catalog_url,
      checked_at: ingestion.snapshot_date,
      stale: false
    },
    geographic_coverage: {
      type: 'not_published',
      requires_residence: 'unknown',
      checked_at: ingestion.snapshot_date
    },
    accessibility_features: [],
    provenance_records: [
      {
        attribute_name: 'specialisation',
        value: profiles.length > 0 ? profiles.map(p => p.term).join(', ') : 'Sin especialización literal en el registro',
        source_dataset: REGISTRY_DATASET.name,
        source_url: REGISTRY_DATASET.catalog_url,
        source_type: 'official_registry',
        source_version: `sha256:${ingestion.sha256.slice(0, 12)} · fila ${r.source_row}`,
        retrieved_at: ingestion.retrieved_at,
        extraction_method: 'structured',
        reviewer,
        reviewer_role: 'data_steward',
        confidence: profiles.length > 0 ? 'explicit' : 'potential',
        quality: 'A'
      },
      {
        attribute_name: 'record',
        value: sourceFragment,
        source_dataset: REGISTRY_DATASET.name,
        source_url: REGISTRY_DATASET.catalog_url,
        source_type: 'official_registry',
        source_version: `sha256:${ingestion.sha256.slice(0, 12)} · fila ${r.source_row}`,
        retrieved_at: ingestion.retrieved_at,
        extraction_method: 'structured',
        reviewer,
        reviewer_role: 'data_steward',
        confidence: 'explicit',
        quality: 'A'
      }
    ],
    last_checked: ingestion.snapshot_date,
    limitations
  };
}
