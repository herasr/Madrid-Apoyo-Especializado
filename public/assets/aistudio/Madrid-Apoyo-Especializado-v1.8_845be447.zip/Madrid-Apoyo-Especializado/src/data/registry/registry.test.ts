import { describe, it, expect } from 'vitest';
import { decodeBytes, detectDelimiter, parseCsvObjects } from './csv';
import { resolveColumns, toRegistryRecord, utm30nToLatLon } from './schema';
import { classifyOwnership, containsTerm, detectLifeStages, detectProfiles, detectSupports, isInScope, registryRecordToCentre, registryText } from './adapter';
import { computeRegistryDiff } from './diff';
import { evaluateCentre } from '../../utils/specializedEngine';
import type { SearchQueryState } from '../../types/specialized';

// Fichero sintético (centros ficticios) con la forma típica de los CSV del portal
const FIXTURE = [
  'Código centro;Denominación;Entidad titular;Titularidad;Tipología;Sector;Dirección;Código postal;Municipio;Teléfono;Plazas;Coordenada X;Coordenada Y;Observaciones',
  '9001;"Centro de Día Ficticio para Personas con Autismo";Asociación Ficticia;Privada;Centro de día;Personas con discapacidad;"Calle Inventada, 1";28001;Madrid;910000001;30;440300;4474200;Adultos',
  '9002;Residencia Ficticia de Mayores;Empresa Ficticia S.L.;Privada;Residencia;Personas mayores;Calle Falsa 2;28901;Getafe;;120;;;',
  '9003;Centro Ficticio de Atención Temprana;Ayuntamiento de Ficticia;Pública;Centro de atención temprana;Personas con discapacidad;Plaza Mayor 3;28801;Alcalá de Henares;;;;;',
  '9004;"Teatro Ficticio ""La Tea""";Fundación Ficticia;;Comedor social;Inclusión;Calle 4;28002;Madrid;;;;;'
].join('\r\n');

const INGESTION = { retrieved_at: '2026-11-12T00:00:00.000Z', snapshot_date: '2026-11-12', sha256: 'f'.repeat(64) };

function loadFixture() {
  const { headers, records } = parseCsvObjects(FIXTURE);
  const { mapping, unmapped } = resolveColumns(headers);
  return { mapping, unmapped, records: records.map((r, i) => toRegistryRecord(r, mapping, unmapped, i + 1)) };
}

describe('Lectura CSV', () => {
  it('detecta «;» y respeta comillas dobles escapadas', () => {
    expect(detectDelimiter(FIXTURE)).toBe(';');
    const { records } = parseCsvObjects(FIXTURE);
    expect(records).toHaveLength(4);
    expect(records[3]['Denominación']).toBe('Teatro Ficticio "La Tea"');
  });

  it('decodifica Windows-1252 cuando el fichero no es UTF-8', () => {
    const latin1 = new Uint8Array([0x44, 0x61, 0xf1, 0x6f]); // «Daño» en Windows-1252
    expect(decodeBytes(latin1)).toEqual({ text: 'Daño', encoding: 'windows-1252' });
  });
});

describe('Normalización del registro', () => {
  it('asigna las cabeceras por alias y conserva las no reconocidas', () => {
    const { mapping, unmapped } = loadFixture();
    expect(mapping.name).toBe('Denominación');
    expect(mapping.municipality).toBe('Municipio');
    expect(mapping.registry_code).toBe('Código centro');
    expect(mapping.utm_x).toBe('Coordenada X');
    expect(unmapped).toContain('Observaciones');
  });

  it('convierte UTM 30N a WGS84 dentro de Madrid', () => {
    const [lat, lon] = utm30nToLatLon(440300, 4474200);
    expect(lat).toBeCloseTo(40.416, 2);
    expect(lon).toBeCloseTo(-3.705, 2);
  });

  it('no inventa coordenadas ni plazas cuando faltan', () => {
    const { records } = loadFixture();
    expect(records[0].lat).not.toBeNull();
    expect(records[0].places).toBe(30);
    expect(records[2].lat).toBeNull();
    expect(records[2].places).toBeNull();
  });
});

describe('Clasificación literal', () => {
  it('las siglas exigen mayúsculas y palabra completa («Tea» de teatro no es TEA)', () => {
    expect(containsTerm('Teatro Ficticio "La Tea"', 'TEA')).toBe(false);
    expect(containsTerm('Centro para personas con TEA', 'TEA')).toBe(true);
  });

  it('detecta perfil, apoyos y etapa vital solo si constan en el texto', () => {
    const { records } = loadFixture();
    const text = registryText(records[0]);
    expect(detectProfiles(text).map(p => p.profile)).toContain('autism');
    expect(detectSupports(text).map(s => s.support)).toEqual(['day_care']);
    expect(detectLifeStages(text)).toEqual(['adult']);
    expect(detectLifeStages(registryText(records[2]))).toEqual(['early_childhood']);
  });

  it('aplica la regla de alcance', () => {
    const { records } = loadFixture();
    const inScope = records.filter(r => isInScope(registryText(r), detectProfiles(registryText(r))));
    expect(inScope.map(r => r.registry_code)).toEqual(['9001', '9003']);
  });

  it('clasifica la titularidad sin suponerla cuando no consta', () => {
    expect(classifyOwnership('Pública', 'Ayuntamiento de Ficticia')).toBe('red_publica');
    expect(classifyOwnership('', 'Empresa Ficticia S.L.')).toBe('privado_autorizado');
    expect(classifyOwnership('', '')).toBe('no_consta');
  });
});

describe('Integración con el motor', () => {
  const baseQuery: SearchQueryState = {
    profile: 'autism', functional_needs: [], support_types: [], support_combination_mode: 'any_support',
    life_stage: null, municipality: null, radius_km: 50, network_preference: 'all',
    accessibility_needs: [], user_ephemeral_location: null, location_mode: 'all'
  };

  it('un centro con «autismo» literal alcanza nivel A con procedencia del registro', () => {
    const { records } = loadFixture();
    const centre = registryRecordToCentre(records[0], INGESTION);
    const res = evaluateCentre(centre, baseQuery, [centre]);
    expect(res.evidence_level.startsWith('A')).toBe(true);
    expect(centre.provenance_records[0].reviewer).toMatch(/automática/);
    expect(centre.availability.vacancies_known).toBe(false);
  });

  it('si el registro no publica edades, la etapa vital queda «debe confirmarse»', () => {
    const { records } = loadFixture();
    const centre = registryRecordToCentre({ ...records[0], extra_text: '' }, INGESTION);
    const res = evaluateCentre(centre, { ...baseQuery, life_stage: 'minor' }, [centre]);
    expect(res.criterion_matrix.find(c => c.criterion_id === 'lifestage.minor')?.status).toBe('confirm_required');
  });
});

describe('Qué ha cambiado', () => {
  it('calcula altas, bajas y cambios reales entre dos ingestas', () => {
    const { records } = loadFixture();
    const [a, b, c] = records.map(r => registryRecordToCentre(r, INGESTION));
    const moved = { ...b, address: 'Calle Nueva 9' };
    const diff = computeRegistryDiff([a, b], [moved, c], '2026-11-05', '2026-11-12');
    expect(diff.summary).toEqual({ added: 1, removed: 1, renamed: 0, changed: 1 });
  });

  it('sin ingesta anterior no hay cambios que mostrar', () => {
    expect(computeRegistryDiff([], [], null, '2026-11-12').changes).toHaveLength(0);
  });
});
