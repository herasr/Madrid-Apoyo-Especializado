/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Normalización de filas del «Registro de centros de atención social»
 * (Comunidad de Madrid, CC BY 4.0) a un registro compacto y trazable.
 *
 * Las cabeceras se reconocen por alias para tolerar cambios menores de
 * nombre en el portal. Las columnas que no se reconocen no se pierden:
 * su texto se conserva en `extra_text` y se usa en la clasificación.
 */

export const REGISTRY_DATASET = {
  name: 'Registro de centros de atención social (Comunidad de Madrid)',
  catalog_url: 'https://datos.comunidad.madrid/catalogo/dataset/atencion_social_registro_centros',
  ckan_package_id: 'atencion_social_registro_centros',
  ckan_api_url: 'https://datos.comunidad.madrid/catalogo/api/3/action/package_show?id=atencion_social_registro_centros',
  csv_url: 'https://datos.comunidad.madrid/dataset/b8cdb7f7-3185-4938-800a-fefda72333f5/resource/0d815439-396e-4975-983e-5bb421f617a0/download/atencion_social_registro_centros.csv',
  json_url: 'https://datos.comunidad.madrid/dataset/b8cdb7f7-3185-4938-800a-fefda72333f5/resource/fb98d116-eb79-4100-8cd4-d5ce2e2c439b/download/atencion_social_registro_centros.json',
  license: 'CC BY 4.0',
  publisher: 'Comunidad de Madrid'
} as const;

export interface RegistryRecord {
  /** Identificador estable: código registral si existe; si no, hash de nombre+dirección+municipio. */
  record_id: string;
  registry_code: string;
  name: string;
  entity: string;
  ownership: string;
  centre_type: string;
  sector: string;
  target_population: string;
  address: string;
  postal_code: string;
  municipality: string;
  district: string;
  phone: string;
  email: string;
  website: string;
  places: number | null;
  lat: number | null;
  lon: number | null;
  registered_at: string;
  status: string;
  /** Texto de columnas no reconocidas («Cabecera: valor | …»). */
  extra_text: string;
  /** Número de fila en el CSV original (1 = primera fila de datos). */
  source_row: number;
}

type FieldKey = Exclude<keyof RegistryRecord, 'record_id' | 'extra_text' | 'source_row' | 'places' | 'lat' | 'lon'>
  | 'places_raw' | 'lat_raw' | 'lon_raw' | 'utm_x' | 'utm_y' | 'street_type' | 'street_name' | 'street_number';

/** Alias por campo, en orden de preferencia (ya normalizados: minúsculas, sin tildes, «_»). */
export const COLUMN_ALIASES: Record<FieldKey, string[]> = {
  registry_code: ['codigo_centro', 'cod_centro', 'codigo_registro', 'n_registro', 'numero_registro', 'num_registro', 'numero_inscripcion', 'n_inscripcion', 'id_centro', 'codigo'],
  name: ['denominacion_centro', 'nombre_centro', 'denominacion', 'nombre', 'centro'],
  entity: ['entidad_titular', 'nombre_entidad', 'titular_centro', 'entidad_gestora', 'titular', 'entidad'],
  ownership: ['tipo_titularidad', 'titularidad', 'naturaleza_juridica', 'naturaleza', 'tipo_entidad'],
  centre_type: ['tipologia_centro', 'tipo_centro', 'tipo_de_centro', 'tipologia', 'subtipologia', 'clase_centro', 'tipo'],
  sector: ['sector_atencion', 'sector', 'colectivo', 'area', 'ambito'],
  target_population: ['poblacion_destinataria', 'colectivo_atendido', 'tipo_usuario', 'usuarios', 'destinatarios'],
  address: ['direccion_centro', 'direccion', 'domicilio'],
  street_type: ['tipo_via'],
  street_name: ['nombre_via', 'via', 'calle'],
  street_number: ['numero_via', 'numero', 'num'],
  postal_code: ['codigo_postal', 'cod_postal', 'cp'],
  municipality: ['municipio', 'nombre_municipio', 'localidad', 'poblacion'],
  district: ['distrito'],
  phone: ['telefono', 'tfno', 'tel'],
  email: ['correo_electronico', 'email', 'e_mail', 'correo', 'mail'],
  website: ['pagina_web', 'web', 'url'],
  places_raw: ['plazas_autorizadas', 'numero_plazas', 'n_plazas', 'plazas', 'capacidad'],
  lat_raw: ['latitud', 'lat'],
  lon_raw: ['longitud', 'lon', 'lng'],
  utm_x: ['coordenada_x', 'utm_x', 'coord_x', 'x_etrs89', 'x'],
  utm_y: ['coordenada_y', 'utm_y', 'coord_y', 'y_etrs89', 'y'],
  registered_at: ['fecha_inscripcion', 'fecha_autorizacion', 'fecha_alta'],
  status: ['estado', 'situacion']
};

export function normalizeHeader(h: string): string {
  return h
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/º|ª/g, '')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

/** Asigna cada campo lógico a una cabecera real del CSV. */
export function resolveColumns(headers: string[]): { mapping: Partial<Record<FieldKey, string>>; unmapped: string[] } {
  const normalized = headers.map(h => ({ raw: h, norm: normalizeHeader(h) }));
  const used = new Set<string>();
  const mapping: Partial<Record<FieldKey, string>> = {};

  // 1.ª pasada: coincidencia exacta; 2.ª pasada: inclusión (solo alias de 5+ caracteres)
  for (const pass of ['exact', 'contains'] as const) {
    for (const field of Object.keys(COLUMN_ALIASES) as FieldKey[]) {
      if (mapping[field]) continue;
      for (const alias of COLUMN_ALIASES[field]) {
        if (pass === 'contains' && alias.length < 5) continue;
        const hit = normalized.find(h => !used.has(h.raw) && (pass === 'exact' ? h.norm === alias : h.norm.includes(alias)));
        if (hit) {
          mapping[field] = hit.raw;
          used.add(hit.raw);
          break;
        }
      }
    }
  }
  return { mapping, unmapped: headers.filter(h => !used.has(h)) };
}

function parseNumber(raw: string | undefined): number | null {
  if (!raw) return null;
  let s = raw.trim().replace(/\s/g, '');
  if (s === '') return null;
  // «1.234,56» → 1234.56 ; «40,41» → 40.41
  if (s.includes(',') && s.includes('.')) s = s.replace(/\./g, '').replace(',', '.');
  else if (s.includes(',')) s = s.replace(',', '.');
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

/** UTM ETRS89 huso 30N → WGS84 (precisión submétrica, suficiente para distancias). */
export function utm30nToLatLon(easting: number, northing: number): [number, number] {
  const a = 6378137;
  const f = 1 / 298.257222101;
  const k0 = 0.9996;
  const e2 = f * (2 - f);
  const ep2 = e2 / (1 - e2);
  const x = easting - 500000;
  const y = northing;
  const lon0 = ((30 - 1) * 6 - 180 + 3) * (Math.PI / 180);

  const m = y / k0;
  const mu = m / (a * (1 - e2 / 4 - (3 * e2 * e2) / 64 - (5 * e2 ** 3) / 256));
  const e1 = (1 - Math.sqrt(1 - e2)) / (1 + Math.sqrt(1 - e2));
  const phi1 = mu
    + ((3 * e1) / 2 - (27 * e1 ** 3) / 32) * Math.sin(2 * mu)
    + ((21 * e1 ** 2) / 16 - (55 * e1 ** 4) / 32) * Math.sin(4 * mu)
    + ((151 * e1 ** 3) / 96) * Math.sin(6 * mu)
    + ((1097 * e1 ** 4) / 512) * Math.sin(8 * mu);

  const n1 = a / Math.sqrt(1 - e2 * Math.sin(phi1) ** 2);
  const t1 = Math.tan(phi1) ** 2;
  const c1 = ep2 * Math.cos(phi1) ** 2;
  const r1 = (a * (1 - e2)) / (1 - e2 * Math.sin(phi1) ** 2) ** 1.5;
  const d = x / (n1 * k0);

  const lat = phi1 - ((n1 * Math.tan(phi1)) / r1) * (
    d ** 2 / 2
    - ((5 + 3 * t1 + 10 * c1 - 4 * c1 ** 2 - 9 * ep2) * d ** 4) / 24
    + ((61 + 90 * t1 + 298 * c1 + 45 * t1 ** 2 - 252 * ep2 - 3 * c1 ** 2) * d ** 6) / 720
  );
  const lon = lon0 + (
    d
    - ((1 + 2 * t1 + c1) * d ** 3) / 6
    + ((5 - 2 * c1 + 28 * t1 - 3 * c1 ** 2 + 8 * ep2 + 24 * t1 ** 2) * d ** 5) / 120
  ) / Math.cos(phi1);

  return [lat * (180 / Math.PI), lon * (180 / Math.PI)];
}

/** Caja envolvente aproximada de la Comunidad de Madrid (con margen). */
export function isInsideMadridRegion(lat: number, lon: number): boolean {
  return lat > 39.85 && lat < 41.2 && lon > -4.65 && lon < -3.0;
}

function resolveCoordinates(get: (k: FieldKey) => string): { lat: number | null; lon: number | null } {
  const lat = parseNumber(get('lat_raw'));
  const lon = parseNumber(get('lon_raw'));
  if (lat !== null && lon !== null && isInsideMadridRegion(lat, lon)) return { lat, lon };

  const x = parseNumber(get('utm_x'));
  const yv = parseNumber(get('utm_y'));
  if (x !== null && yv !== null && x > 100000 && yv > 4000000) {
    const [la, lo] = utm30nToLatLon(x, yv);
    if (isInsideMadridRegion(la, lo)) return { lat: la, lon: lo };
  }
  return { lat: null, lon: null };
}

/** FNV-1a de 32 bits: identificador estable cuando no hay código registral. */
export function stableHash(text: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16).padStart(8, '0');
}

export function toRegistryRecord(
  row: Record<string, string>,
  mapping: Partial<Record<FieldKey, string>>,
  unmapped: string[],
  sourceRow: number
): RegistryRecord {
  const get = (k: FieldKey) => {
    const col = mapping[k];
    return col ? (row[col] ?? '').trim() : '';
  };

  let address = get('address');
  if (!address) {
    address = [get('street_type'), get('street_name'), get('street_number')].filter(Boolean).join(' ').trim();
  }

  const { lat, lon } = resolveCoordinates(get);
  const name = get('name');
  const registryCode = get('registry_code');
  const municipality = get('municipality');

  const extra_text = unmapped
    .map(h => (row[h] ?? '').trim() ? `${h}: ${row[h].trim()}` : '')
    .filter(Boolean)
    .join(' | ');

  return {
    record_id: registryCode ? `REG-${registryCode}` : `REG-H${stableHash(`${name}|${address}|${municipality}`)}`,
    registry_code: registryCode,
    name,
    entity: get('entity'),
    ownership: get('ownership'),
    centre_type: get('centre_type'),
    sector: get('sector'),
    target_population: get('target_population'),
    address,
    postal_code: get('postal_code'),
    municipality,
    district: get('district'),
    phone: get('phone'),
    email: get('email'),
    website: get('website'),
    places: parseNumber(get('places_raw')),
    lat,
    lon,
    registered_at: get('registered_at'),
    status: get('status'),
    extra_text,
    source_row: sourceRow
  };
}
