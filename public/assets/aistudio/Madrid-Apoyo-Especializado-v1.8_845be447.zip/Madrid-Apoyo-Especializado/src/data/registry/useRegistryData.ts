/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Carga en el navegador los datos generados por `npm run ingest`
 * (public/data/registry/*.json). Sin datos de respaldo inventados:
 * si los ficheros no existen, la interfaz lo dice.
 */

import { useEffect, useState } from 'react';
import type { SpecializedCentre } from '../../types/specialized';
import type { RegistryDiff } from './diff';
import type { RegistryRecord } from './schema';
import { registryRecordToCentre } from './adapter';

export interface RegistryMeta {
  ingestion_id: string;
  status: 'SUCCESS';
  timestamp: string;
  snapshot_date: string;
  dataset: string;
  catalog_url: string;
  license: string;
  source_url: string;
  sha256: string;
  counts: {
    csv_rows: number;
    valid_records: number;
    in_scope: number;
    with_coordinates: number;
    with_explicit_profile: number;
    with_life_stage_in_registry: number;
    with_contact: number;
    by_profile: Record<string, number>;
  };
  scope_rule: string;
}

export type RegistryState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'ready'; centres: SpecializedCentre[]; meta: RegistryMeta; diff: RegistryDiff | null };

const base = (import.meta as { env?: { BASE_URL?: string } }).env?.BASE_URL ?? '/';

async function getJson<T>(file: string): Promise<T> {
  const res = await fetch(`${base}data/registry/${file}`, { cache: 'no-cache' });
  if (!res.ok) throw new Error(`${file}: HTTP ${res.status}`);
  return res.json() as Promise<T>;
}

export function useRegistryData(): RegistryState {
  const [state, setState] = useState<RegistryState>({ status: 'loading' });

  useEffect(() => {
    let cancelled = false;
    Promise.all([
      getJson<RegistryRecord[]>('records.json'),
      getJson<RegistryMeta>('meta.json'),
      getJson<RegistryDiff>('diff.json').catch(() => null)
    ])
      .then(([records, meta, diff]) => {
        const ingestion = { retrieved_at: meta.timestamp, snapshot_date: meta.snapshot_date, sha256: meta.sha256 };
        const centres = records.map(r => registryRecordToCentre(r, ingestion));
        if (!cancelled) setState({ status: 'ready', centres, meta, diff });
      })
      .catch(err => {
        if (!cancelled) {
          setState({
            status: 'error',
            message: `No se han podido cargar los datos del registro (${err instanceof Error ? err.message : err}). Ejecute «npm run ingest».`
          });
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return state;
}
