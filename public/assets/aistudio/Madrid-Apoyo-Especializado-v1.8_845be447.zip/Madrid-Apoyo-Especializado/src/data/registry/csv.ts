/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Lector CSV sin dependencias (RFC 4180) para los ficheros del portal
 * datos.comunidad.madrid: detecta separador («;» o «,»), BOM y codificación.
 */

/** Decodifica bytes como UTF-8 y, si aparecen caracteres inválidos, como Windows-1252. */
export function decodeBytes(bytes: Uint8Array): { text: string; encoding: 'utf-8' | 'windows-1252' } {
  const utf8 = new TextDecoder('utf-8', { fatal: false }).decode(bytes);
  if (!utf8.includes('�')) {
    return { text: stripBom(utf8), encoding: 'utf-8' };
  }
  const latin = new TextDecoder('windows-1252').decode(bytes);
  return { text: stripBom(latin), encoding: 'windows-1252' };
}

export function stripBom(text: string): string {
  return text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
}

/** Elige el separador más frecuente fuera de comillas en la primera línea. */
export function detectDelimiter(text: string): string {
  const firstLine = text.split(/\r?\n/, 1)[0] ?? '';
  const candidates = [';', ',', '\t', '|'];
  let best = ';';
  let bestCount = -1;
  for (const d of candidates) {
    let count = 0;
    let inQuotes = false;
    for (const ch of firstLine) {
      if (ch === '"') inQuotes = !inQuotes;
      else if (ch === d && !inQuotes) count++;
    }
    if (count > bestCount) {
      best = d;
      bestCount = count;
    }
  }
  return best;
}

/** Devuelve todas las filas como arrays de celdas (sin recortar). */
export function parseCsvRows(text: string, delimiter = detectDelimiter(text)): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          cell += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        cell += ch;
      }
      continue;
    }
    if (ch === '"') {
      inQuotes = true;
    } else if (ch === delimiter) {
      row.push(cell);
      cell = '';
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = '';
    } else {
      cell += ch;
    }
  }
  if (cell !== '' || row.length > 0) {
    row.push(cell);
    rows.push(row);
  }
  return rows.filter(r => r.some(c => c.trim() !== ''));
}

/** Convierte el CSV en objetos usando la primera fila como cabecera. */
export function parseCsvObjects(text: string): { headers: string[]; records: Record<string, string>[]; delimiter: string } {
  const delimiter = detectDelimiter(text);
  const rows = parseCsvRows(text, delimiter);
  if (rows.length === 0) return { headers: [], records: [], delimiter };
  const headers = rows[0].map(h => h.trim());
  const records = rows.slice(1).map(r => {
    const obj: Record<string, string> = {};
    headers.forEach((h, idx) => {
      obj[h] = (r[idx] ?? '').trim();
    });
    return obj;
  });
  return { headers, records, delimiter };
}
