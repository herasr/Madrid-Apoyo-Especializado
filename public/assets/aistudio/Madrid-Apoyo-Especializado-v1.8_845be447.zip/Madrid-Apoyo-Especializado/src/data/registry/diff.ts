/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * «Qué ha cambiado»: comparación real entre dos ingestas del registro.
 */

import type { SnapshotDifference, SpecializedCentre } from '../../types/specialized';

export interface RegistryDiff {
  previous_snapshot: string | null;
  current_snapshot: string;
  summary: { added: number; removed: number; renamed: number; changed: number };
  changes: SnapshotDifference[];
}

const WATCHED: { key: keyof SpecializedCentre; label: string }[] = [
  { key: 'centre_type', label: 'tipología' },
  { key: 'address', label: 'dirección' },
  { key: 'municipality', label: 'municipio' },
  { key: 'management_type', label: 'titularidad' },
  { key: 'provider_name', label: 'entidad titular' },
  { key: 'phone', label: 'teléfono' }
];

export function computeRegistryDiff(
  previous: SpecializedCentre[],
  current: SpecializedCentre[],
  previousDate: string | null,
  currentDate: string
): RegistryDiff {
  const changes: SnapshotDifference[] = [];
  const summary = { added: 0, removed: 0, renamed: 0, changed: 0 };
  if (!previousDate || previous.length === 0) {
    return { previous_snapshot: null, current_snapshot: currentDate, summary, changes };
  }

  const prevById = new Map(previous.map(c => [c.centre_id, c]));
  const currById = new Map(current.map(c => [c.centre_id, c]));
  let n = 0;
  const push = (d: Omit<SnapshotDifference, 'change_id' | 'previous_snapshot' | 'current_snapshot'>) => {
    changes.push({ change_id: `DIFF-${String(++n).padStart(4, '0')}`, previous_snapshot: previousDate, current_snapshot: currentDate, ...d });
  };

  for (const c of current) {
    const p = prevById.get(c.centre_id);
    if (!p) {
      summary.added++;
      push({ change_type: 'centre_added', centre_id: c.centre_id, centre_name: c.official_name, detail: `Nuevo en el registro: ${c.centre_type || 'tipología no publicada'} · ${c.municipality}.`, reason: 'Aparece en la ingesta actual y no en la anterior.', category: 'alta' });
      continue;
    }
    if (p.official_name !== c.official_name) {
      summary.renamed++;
      push({ change_type: 'centre_renamed', centre_id: c.centre_id, centre_name: c.official_name, detail: `Antes: «${p.official_name}».`, reason: 'Cambio de denominación en el registro.', category: 'servicio' });
    }
    const fieldChanges = WATCHED.filter(w => String(p[w.key] ?? '') !== String(c[w.key] ?? ''));
    if (fieldChanges.length) {
      summary.changed++;
      push({
        change_type: 'attributes_changed',
        centre_id: c.centre_id,
        centre_name: c.official_name,
        detail: fieldChanges.map(w => `${w.label}: «${String(p[w.key] ?? '') || '—'}» → «${String(c[w.key] ?? '') || '—'}»`).join(' · '),
        reason: 'Atributos modificados en el registro.',
        category: 'datos'
      });
    }
  }
  for (const p of previous) {
    if (!currById.has(p.centre_id)) {
      summary.removed++;
      push({ change_type: 'centre_removed', centre_id: p.centre_id, centre_name: p.official_name, detail: `Ya no figura en el registro (${p.municipality}).`, reason: 'Presente en la ingesta anterior y ausente en la actual.', category: 'baja' });
    }
  }
  return { previous_snapshot: previousDate, current_snapshot: currentDate, summary, changes };
}
