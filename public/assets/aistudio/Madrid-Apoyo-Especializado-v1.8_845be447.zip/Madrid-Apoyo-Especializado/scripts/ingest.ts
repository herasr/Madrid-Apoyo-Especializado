/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Madrid Apoyo Especializado — Ingesta del Registro de centros de atención social
 *
 * Uso:
 *   npm run ingest                      # descarga del portal datos.comunidad.madrid
 *   npm run ingest -- --file ruta.csv   # ingesta de un CSV descargado a mano
 *
 * Principios:
 *   - Si la descarga o la validación fallan, el proceso termina con error y NO
 *     escribe nada: nunca se sustituyen los datos oficiales por datos de ejemplo.
 *   - Todos los contadores del informe se calculan sobre los datos reales.
 *   - Cada ingesta queda registrada con su huella SHA-256 en ingestion-log.json.
 */

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { decodeBytes, parseCsvObjects } from '../src/data/registry/csv';
import { REGISTRY_DATASET, resolveColumns, toRegistryRecord, RegistryRecord } from '../src/data/registry/schema';
import { detectProfiles, isInScope, registryRecordToCentre, registryText, SCOPE_TERMS } from '../src/data/registry/adapter';
import { computeRegistryDiff } from '../src/data/registry/diff';
import type { SpecializedCentre } from '../src/types/specialized';

const ROOT = process.cwd();
const OUT_DIR = path.join(ROOT, 'public/data/registry');
const MIN_BYTES = 10_000;
const MIN_RECORDS = 100;
const USER_AGENT = 'MadridApoyoEspecializado/1.8 (+https://github.com/herasr/Madrid-Apoyo-Especializado)';

class IngestError extends Error {}

async function resolveCsvUrl(): Promise<string> {
  try {
    const res = await fetch(REGISTRY_DATASET.ckan_api_url, { headers: { 'User-Agent': USER_AGENT } });
    if (res.ok) {
      const body = await res.json() as { result?: { resources?: { format?: string; url?: string; name?: string }[] } };
      const csv = body.result?.resources?.find(r => (r.format || '').toUpperCase() === 'CSV' && /atencion_social_registro_centros\.csv$/.test(r.url || ''))
        ?? body.result?.resources?.find(r => (r.format || '').toUpperCase() === 'CSV' && !/historico|zip/i.test(r.url || ''));
      if (csv?.url) return csv.url;
    }
  } catch {
    // Se usa la URL directa documentada
  }
  return REGISTRY_DATASET.csv_url;
}

async function download(url: string): Promise<Uint8Array> {
  const res = await fetch(url, { headers: { 'User-Agent': USER_AGENT } });
  if (!res.ok) throw new IngestError(`HTTP ${res.status} al descargar ${url}`);
  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('text/html')) throw new IngestError(`El servidor devolvió HTML en lugar de CSV (${url}).`);
  return new Uint8Array(await res.arrayBuffer());
}

function readArgs() {
  const idx = process.argv.indexOf('--file');
  return { file: idx > -1 ? process.argv[idx + 1] : null };
}

function readJson<T>(p: string, fallback: T): T {
  try {
    return JSON.parse(fs.readFileSync(p, 'utf-8')) as T;
  } catch {
    return fallback;
  }
}

export async function runIngestionProcess() {
  const { file } = readArgs();
  const startedAt = new Date();
  const timestamp = startedAt.toISOString();
  const snapshotDate = timestamp.slice(0, 10);

  // 1. Obtener bytes
  let sourceUrl: string;
  let bytes: Uint8Array;
  if (file) {
    sourceUrl = `file:${path.basename(file)} (descargado de ${REGISTRY_DATASET.catalog_url})`;
    bytes = new Uint8Array(fs.readFileSync(path.resolve(file)));
  } else {
    sourceUrl = await resolveCsvUrl();
    console.log(`Descargando ${sourceUrl}`);
    bytes = await download(sourceUrl);
  }

  // 2. Validar
  if (bytes.byteLength < MIN_BYTES) throw new IngestError(`Fichero demasiado pequeño (${bytes.byteLength} bytes).`);
  const { text, encoding } = decodeBytes(bytes);
  if (/^\s*<(!doctype|html)/i.test(text)) throw new IngestError('El contenido es una página HTML, no un CSV.');

  const sha256 = crypto.createHash('sha256').update(bytes).digest('hex');
  const { headers, records: rows, delimiter } = parseCsvObjects(text);
  const { mapping, unmapped } = resolveColumns(headers);
  if (!mapping.name || !mapping.municipality) {
    throw new IngestError(`No se reconocen las columnas de nombre/municipio. Cabeceras: ${headers.join(' | ')}`);
  }

  // 3. Normalizar, descartar bajas y duplicados
  const seen = new Set<string>();
  const valid: RegistryRecord[] = [];
  let droppedEmpty = 0;
  let droppedClosed = 0;
  let droppedDuplicate = 0;
  rows.forEach((row, i) => {
    const rec = toRegistryRecord(row, mapping, unmapped, i + 1);
    if (!rec.name) { droppedEmpty++; return; }
    if (/\b(baja|cancelad|cerrad|extingui)/i.test(rec.status)) { droppedClosed++; return; }
    if (seen.has(rec.record_id)) { droppedDuplicate++; return; }
    seen.add(rec.record_id);
    valid.push(rec);
  });
  if (valid.length < MIN_RECORDS) throw new IngestError(`Solo ${valid.length} registros válidos (mínimo ${MIN_RECORDS}).`);

  // 4. Alcance y conversión
  const inScope = valid.filter(r => isInScope(registryText(r), detectProfiles(registryText(r))));
  const centres: SpecializedCentre[] = inScope.map(r => registryRecordToCentre(r, { retrieved_at: timestamp, snapshot_date: snapshotDate, sha256 }));

  const profileCounts: Record<string, number> = {};
  centres.forEach(c => c.explicit_specialisations.forEach(p => { profileCounts[p] = (profileCounts[p] || 0) + 1; }));

  // 5. Diferencias con la ingesta anterior
  fs.mkdirSync(OUT_DIR, { recursive: true });
  const recordsPath = path.join(OUT_DIR, 'records.json');
  const previousMeta = readJson<{ snapshot_date?: string; sha256?: string; timestamp?: string } | null>(path.join(OUT_DIR, 'meta.json'), null);
  const previousCentres = readJson<RegistryRecord[]>(recordsPath, []).map(r =>
    registryRecordToCentre(r, { retrieved_at: previousMeta?.timestamp ?? '', snapshot_date: previousMeta?.snapshot_date ?? '', sha256: previousMeta?.sha256 ?? '' })
  );
  const diff = computeRegistryDiff(previousCentres, centres, previousMeta?.snapshot_date ?? null, snapshotDate);

  const meta = {
    ingestion_id: `ING_${startedAt.getTime()}`,
    status: 'SUCCESS' as const,
    timestamp,
    snapshot_date: snapshotDate,
    dataset: REGISTRY_DATASET.name,
    catalog_url: REGISTRY_DATASET.catalog_url,
    license: REGISTRY_DATASET.license,
    source_url: sourceUrl,
    sha256,
    file_size_bytes: bytes.byteLength,
    encoding,
    delimiter,
    headers,
    column_mapping: mapping,
    unmapped_columns: unmapped,
    counts: {
      csv_rows: rows.length,
      valid_records: valid.length,
      dropped_empty_name: droppedEmpty,
      dropped_closed: droppedClosed,
      dropped_duplicate: droppedDuplicate,
      in_scope: centres.length,
      with_coordinates: centres.filter(c => c.has_valid_coordinates).length,
      with_explicit_profile: centres.filter(c => c.explicit_specialisations.length > 0).length,
      with_life_stage_in_registry: centres.filter(c => c.life_stages_source === 'registry_text').length,
      with_contact: centres.filter(c => c.phone || c.email).length,
      by_profile: profileCounts
    },
    scope_rule: `Se incluyen los centros cuyo texto registral menciona un perfil de la taxonomía o alguno de: ${SCOPE_TERMS.join(', ')}.`,
    previous: previousMeta ? { snapshot_date: previousMeta.snapshot_date, sha256: previousMeta.sha256 } : null,
    unchanged_since_previous: previousMeta?.sha256 === sha256
  };

  // 6. Escribir (solo tras validar todo)
  fs.writeFileSync(path.join(OUT_DIR, 'registro-centros-latest.csv'), bytes);
  fs.writeFileSync(recordsPath, JSON.stringify(inScope));
  fs.writeFileSync(path.join(OUT_DIR, 'meta.json'), JSON.stringify(meta, null, 2));
  fs.writeFileSync(path.join(OUT_DIR, 'diff.json'), JSON.stringify(diff, null, 2));
  const logPath = path.join(OUT_DIR, 'ingestion-log.json');
  const log = readJson<unknown[]>(logPath, []);
  log.push({ ingestion_id: meta.ingestion_id, timestamp, sha256, source_url: sourceUrl, counts: { csv_rows: rows.length, valid_records: valid.length, in_scope: centres.length } });
  fs.writeFileSync(logPath, JSON.stringify(log, null, 2));

  console.log(`OK · ${rows.length} filas · ${valid.length} válidas · ${centres.length} en alcance · ${meta.counts.with_coordinates} con coordenadas`);
  console.log(`SHA-256 ${sha256}`);
  if (unmapped.length) console.log(`Columnas sin asignar (se usan como texto libre): ${unmapped.join(', ')}`);
  return meta;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  runIngestionProcess().catch(err => {
    console.error(`INGESTA FALLIDA: ${err instanceof Error ? err.message : err}`);
    console.error('No se ha modificado ningún fichero de datos.');
    process.exit(1);
  });
}
